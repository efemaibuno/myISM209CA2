from flask import Flask, render_template



app = Flask(__name__)

@app.route("/")
def home():
 return '''My name is Ezaga Efemaibuno. This is my CA2 work.
 My GitHub URL is https://github.com/efemaibuno/myISM209CA2'''



@app.route("/registration", methods=['POST'])
def registration():
    return render_template('home.html', title= "User Registration")
firstname = request.form['firstname']
lastname = request.form['lastname']
date_of_birth = request.form['dateofbirth']
residential_address = request.form['residentialaddress']
nationality = request.form['nationality[']
national_identification_number = request.form['nationalidentificationnumber']










if __name__ == "__main__":
 app.run(port=5005)